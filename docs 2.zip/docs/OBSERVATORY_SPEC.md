# Observatory Spec

EDEN v1.2 keeps Python authoritative for exports, clustering, basin projection, and measurement provenance while replacing the inline canvas artifacts with one checked-in React + TypeScript + Vite observatory bundle. The browser layer is now a live-first graph workbench in Gephi-style browser grammar: Overview, Data Laboratory, and Preview are distinct top-level workspaces while authority boundaries, preview-first mutation, and measurement provenance remain explicit.

## Artifact families

Generated per experiment under `exports/<experiment_id>/`:

- `graph_knowledge_base.html`
- `graph_knowledge_base.json`
- `graph_knowledge_base.manifest.json`
- `behavioral_attractor_basin.html`
- `behavioral_attractor_basin.json`
- `behavioral_attractor_basin.manifest.json`
- `geometry_lab.html`
- `geometry_diagnostics.json`
- `geometry_manifest.json`
- `measurement_ledger.html`
- `measurement_events.json`
- `measurement_events.manifest.json`
- `tanakh_manifest.json`
- `tanakh_index.json`
- `tanakh_surface.json`
- `tanakh_measurements.json`
- `tanakh_render_validation.json`
- `tanakh_render_validation.html`
- `tanakh_passage_cache/<ref>.json`
- `tanakh_scene_<id>.json`
- `observatory_index.html`
- `observatory_index.json`
- `_observatory_app/` checked-in frontend bundle copied from `eden/observatory/static/observatory_app/`

## Observatory modes

- `INSPECT`
  - hover, pin, inspect provenance, regard, local neighborhood, and measurement history
- `MEASURE`
  - compute local motif metrics or geometry deltas without mutating topology
- `EDIT`
  - add/update/remove edges with provenance
  - assert known memodes
  - refine memode membership
- `ABLATE`
  - preview masked-edge comparisons and relation-class perturbations
- `COMPARE`
  - compare slices, coordinate methods, or baseline vs modified states

## Workspace grammar

- the browser shell opens into three top-level tabs:
  - `Overview`
  - `Data Laboratory`
  - `Preview`
- `Overview` is the default graph-exploration cockpit
- `Data Laboratory` is the spreadsheet audit surface for nodes and edges
- `Preview` is a separate final-render/export stage whose settings affect export appearance rather than graph semantics
- the browser workbench uses a deterministic dock grammar rather than arbitrary drag docking:
  - left dock for `Appearance` and `Layout`
  - center graph canvas with the graph-mode strip, tool rail, and fold-out render tray
  - right dock for `Statistics`, `Filters`, `Context`, `Inspector`, `Queries`, `Memode Audit`, action/ledger/runtime adjuncts, and payload diagnostics
- the workbench exposes collapse/expand and `Reset layout`; dock proportions and collapse state are browser-local and resettable
- selection synchronizes across graph, inspector, Data Laboratory rows, and preview-oriented compare surfaces without silently mutating the graph

## Status row and continuity strip

- the browser shell keeps a thin status row visible beneath the top workspace tabs instead of using the continuity strip as the dominant shell header
- the row contains:
  - a persistent hum fact card grounded in the bounded hum artifact summary
  - an operator-visible reasoning card with a radio-group lens switcher:
    - `Reasoning`
    - `Chain-Like`
    - `Hum Live`
- the row also carries source-mode/build-freshness honesty and lightweight aperture/runtime status so the operator can verify live/static state without losing graph-first focus
- `Hum Live` reformats the bounded hum text surface as chain-like continuity beats; it does not claim hidden chain-of-thought
- operator-visible reasoning in the browser is sourced from live session transcript payloads when available; static export alone may not provide a current reasoning artifact

## Graph knowledge base

- authoritative graph payload planes:
  - `semantic_nodes`
  - `semantic_edges`
  - `assembly_nodes`
  - `assembly_edges`
  - `runtime_nodes`
  - `runtime_edges`
  - `assemblies`
  - `memode_audit`
  - `cluster_summaries`
  - `active_set_slices`
- browser workbench metadata surfaces:
  - `layout_families`
  - `layout_catalog`
  - `layout_defaults`
  - `appearance_dimensions`
  - `filter_dimensions`
  - `statistics_capabilities`
  - `export_formats`
- legacy `nodes` / `edges` remain for one compatibility release only
- semantic clustering is computed only on the meme-only semantic subgraph with deterministic Louvain settings, canonical node ordering, and versioned tokenization/labeling inputs
- graph UI grammar is explicit:
  - `Semantic Map`
  - `Assemblies`
  - `Runtime`
  - `Active Set`
  - `Compare`
- `Semantic Map` shows behavior-domain memes only, semantic support edges, cluster hull/label summaries, and memode overlays
- memodes render as second-order assemblies with `hulls`, `collapsed-meta-node`, or `hidden` overlay modes; they are not default peer dots
- `Assemblies` exposes the ontology-projected second-order plane directly: behavior memes, constative information nodes, informational knowledge relations, and explicit behavior-memode membership edges are all exportable/readable there without pretending they belong to the clustering-only semantic map
- `assembly_nodes` / `assembly_edges` are the authoritative graph slice for `Assemblies`; `assemblies` is a summary/audit surface and must not be treated as peer graph nodes during browser lookup or export
- for legacy graphs that still store only snippet-like knowledge rows, `Assemblies` may project additional author/work/information nodes with `storage_kind = "projection"` so exports stay truthful before session-start normalization persists those entities into the graph proper
- projectable behavior memodes inherit a dominant `cluster_signature` / `cluster_label` from their member behavior memes so the second-order plane remains inspectable against the semantic cluster surface
- label disclosure is progressive and non-hover-dependent:
  - cluster labels first
  - selected / pinned / high-centrality meme labels next
  - edge labels only on focus or selection
- inspector surfaces structured cards for identity, ontology, domain, provenance, evidence/confidence, cluster membership, memode membership, supporting relations, active-set presence, measurement history, and preview delta
- raw JSON survives only as a debug tab
- coordinate modes remain explicit view modes, not evidence claims
- `memode_audit` is a derived audit plane over the full meme/edge graph. It keeps materialized memode support edges distinct from unmaterialized support candidates and informational knowledge relations that remain non-memetic.

## Browser-local workbench surfaces

- `Overview` keeps the graph canvas as the dominant surface and embeds graph-reading modes as an in-canvas strip:
  - `Semantic Map`
  - `Assemblies`
  - `Runtime`
  - `Active Set`
  - `Compare`
- `Overview` exposes explicit interaction controls for `INSPECT`, `MEASURE`, `EDIT`, `ABLATE`, and `COMPARE`
- the left dock organizes browser-local `Appearance` and `Layout` controls in Gephi-style operator grammar:
  - appearance changes color, size, captions, and label behavior without mutating graph facts
  - layout runs worker-backed browser layouts with run/pause/cancel/reset/snapshot controls while remaining non-evidentiary
- the center graph canvas includes:
  - a left tool rail for select, pan, box-select, pin, recenter/fit, and graph-to-table handoff
  - a fold-out bottom render tray for label, overlay, and coordinate rendering controls
  - reset-camera and fit-graph actions
- the right dock hosts:
  - `Statistics`
  - `Filters`
  - `Context`
  - `Inspector`
  - `Queries`
  - `Memode Audit`
  - action / precision-drawer controls
  - measurement ledger
  - runtime trace
  - basin/geometry/tanakh/payload diagnostics when requested
- compare mode renders baseline vs modified state from preview responses without committing mutation
- local layout execution is browser-only:
  - layouts run through a worker-backed `LayoutRunner`
  - the layout picker is organized as a 12-family terrain browser spanning force-directed, hierarchical, tree, circular, spectral, multilevel, constraint, orthogonal, planar, geographic, community, and edge-bundling families
  - every terrain item carries operator-facing explanation copy for what it is and how it is typically used
  - runnable browser-worker layouts currently include `forceatlas2`, `fruchterman_reingold`, `kamada_kawai`, `linlog`, `sugiyama_layered`, `radial_tree`, `simple_circular`, `circular_degree`, `circular_community`, `radial`, `noverlap`, `fixed_coordinate`, and `community_clusters`
  - many additional algorithms are exposed as reference-only terrain items so the operator can browse the wider layout landscape without EDEN pretending they execute locally
  - presets and layout snapshots persist in browser-local storage keyed by experiment identity plus manifest / graph hash
  - layout, filter, appearance, and table state do not enter the measurement ledger
- appearance controls can style node / edge color, size, label visibility, and opacity from EDEN attributes such as kind, domain, cluster, evidence label, active-set presence, degree, weight, and regard/reward/risk where present
- node appearance/filter metadata now also carries `entity_type`, `speech_act_mode`, and `storage_kind` so browser/export surfaces can distinguish projected ontology from compatibility-table storage
- filter controls are organized around attribute/topology-style workbench filters and can constrain text, attribute/range slices, connected components, isolated-node visibility, and ego neighborhoods without mutating graph facts
- the `Context` panel is the aperture/active-set summary surface: it reports visible node/edge counts, domain and memode counts, active document count, active filters, and current scope while deeper evidence drill-down remains separate
- the Data Laboratory provides:
  - `Nodes` and `Edges` sub-tabs
  - sortable columns
  - browser-local search/filtering
  - show/hide columns
  - safe bulk selection/export actions
  - graph-to-table and table-to-graph selection synchronization
  - explicit `export scope` controls alongside stable ids, `export_label`, ontology, provenance, evidence/confidence, memode membership, and measurement-history summaries where present
- the Data Lab export surface preserves the existing `current view` workflow and also exposes explicit ontology export scopes:
  - `current view`
  - `full ontology`
  - `behavior only`
  - `information only`
- `full ontology` is derived from the authoritative `Assemblies` plane so memodes remain exportable in context with both constative information and performative behavior
- the `Preview` workspace is a separate final-render stage:
  - preview settings alter label, edge-opacity, curvature, background, caption, legend, and export-scope presentation
  - preview settings stay browser-local and require explicit `Refresh preview`
  - preview styling never mutates topology, semantic state, or measurement events
- the `Memode Audit` workbench provides:
  - per-memode admissibility status
  - member meme inspection
  - materialized support-edge inspection
  - member-local informational relation inspection
  - unmaterialized meme-to-meme relation inspection across the current graph payload
- export interoperability includes Gephi-accepted graph documents for the selected export scope (`current view`, `full ontology`, `behavior only`, or `information only`): `gexf`, `graphml`, `gdf`, `gml`, `graphviz dot`, `pajek net`, `netdraw vna`, `ucinet dl`, `tulip tlp`, `tgf`, plus node/edge CSV tables for Gephi spreadsheet import

## Public browser payload contract

- graph payloads expose layout, appearance, filter, statistics, and export capability metadata so the React shell can stay declarative instead of hard-coding instrument assumptions
- graph payload nodes and edges can expose `export_label` alongside stable internal ids so graph-document downloads can carry semantic labels into Gephi without sacrificing referential identity
- graph payloads expose `assembly_nodes` and `assembly_edges` as a distinct second-order plane so `Assemblies` mode can show/export memode topology without collapsing it into the meme-only semantic slice
- graph payload nodes expose projected ontology fields: `kind`, `entity_type`, `speech_act_mode`, and `storage_kind`
- graph payloads may include projected legacy information entities whose stable ids begin with `projection::information::`; these are export/runtime read-path repairs rather than persisted graph rows
- graph payload layout metadata includes:
  - `layout_families`
  - `layout_catalog`
  - `layout_defaults`
- payload layout metadata may be partial; the checked-in frontend terrain catalog fills unspecified reference/explanation entries so older static exports still render the full layout landscape truthfully
- preview responses expose:
  - `compare_selection`
  - `preview_graph_patch`
- `preview_graph_patch` is a browser compare artifact only; it is not a persisted graph fact
- when live session context exists, the shell bootstrap exposes `session_trace` alongside `preview`, `commit`, and `revert`

## Measurement-first contract

1. Select nodes or an edge.
2. Propose an action in the precision drawer.
3. Preview before/after metric deltas plus `preview_graph_patch` baseline vs modified state.
4. Commit only if the change is warranted.
5. Persist the event with provenance.
6. Refresh graph, geometry, measurement ledger, and runtime trace views.
7. Revert explicitly if needed.

Observation does not silently mutate the graph. Mutation is a separate, attributable step.
Layout, styling, filter presets, table sort state, and coordinate-mode choices remain browser-local view state and are not evidence.

## Behavioral attractor basin

- turn trajectory computed from real turn features
- explicit projection provenance (`svd_on_turn_features`)
- projection metadata includes:
  - `projection_method`
  - `projection_version`
  - `projection_input_hash`
  - `source_turn_count`
  - `filtered_turn_count`
- per-turn overlays for:
  - inference profile
  - requested/effective mode
  - budget pressure
  - remaining input budget
  - membrane-event counts
  - active-set recurrence
  - phase-transition markers
- stable per-turn and per-attractor identity fields include dominant node, dominant memode, dominant cluster signature, and display attractor label
- basin lift modes are explicit derived rendering choices:
  - `flat`
  - `time_lift`
  - `density_lift`
  - `session_offset`
- the UI surfaces projection method, lift mode, and derived-status badges directly in the controls and inspector
- sparse basin payloads are honest: if fewer than two turns survive filtering, the browser shows a diagnostic empty state instead of a fake basin

## Geometry lab

- global geometry diagnostics
- slice views:
  - `full_graph`
  - `current_session`
  - `current_active_set`
  - `latest_active_set`
  - verdict slices when populated
  - memode-local slices when populated
- local selection measurement over the live API when available
- metric evidence labels:
  - `OBSERVED`
  - `DERIVED`
  - `SPECULATIVE`
  - operator assertion labels surfaced separately from geometry evidence labels

## Tanakh tool-surface

- the Tanakh surface is an additive observatory instrument, not a replacement runtime
- canonical Tanakh reading stays DOM/CSS-based unless a separate render-validation proof upgrades that claim
- derived analyzers are exposed as explicit sidecars:
  - `get_passage`
  - `gematria`
  - `notarikon`
  - `temurah`
  - `compile_merkavah_scene`
- every Tanakh payload carries provenance for:
  - canonical citation or raw source
  - dataset id / text version / build / archive hash
  - preprocessing choices
  - operator version
  - parameterization
  - creation timestamp
  - output kind (`canonical_text`, `derived_transformation`, or `derived_visualization`)
- the first merkavah slice is explicitly derived:
  - canonical entry ref defaults to `Ezek 1`
  - same ref + params produce hash-stable scene JSON
  - `sceneNodeId -> citation span` linkage is exported in the scene payload
- Tanakh runs are surfaced in observatory sidecar artifacts and overview badges; they are not silently promoted to first-class measurement events

## Local observatory server

CLI:

```bash
.venv/bin/python -m eden observatory --host 127.0.0.1 --port 8741 --open
```

Behavior:

- if the requested port is free, EDEN uses it
- if the requested port is already serving the same exports root, EDEN reuses it
- if the requested port is occupied by something else, EDEN walks to the next free port in a bounded range
- the actual URL is printed as JSON
- server info is persisted at `exports/.eden_observatory.json`

Live API:

- `GET /api/status`
- `GET /api/experiments`
- `GET /api/experiments/<experiment_id>/payload`
- `GET /api/experiments/<experiment_id>/overview`
- `GET /api/experiments/<experiment_id>/graph`
- `GET /api/experiments/<experiment_id>/basin`
- `GET /api/experiments/<experiment_id>/geometry`
- `GET /api/experiments/<experiment_id>/measurement-events`
- `GET /api/experiments/<experiment_id>/tanakh`
- `GET /api/experiments/<experiment_id>/sessions`
- `GET /api/sessions/<session_id>/turns`
- `GET /api/sessions/<session_id>/active-set`
- `GET /api/sessions/<session_id>/trace`
- `GET /api/runtime/status`
- `GET /api/runtime/model`
- `GET /api/experiments/<experiment_id>/events` (SSE invalidation stream)
- `POST /api/experiments/<experiment_id>/preview`
- `POST /api/experiments/<experiment_id>/commit`
- `POST /api/experiments/<experiment_id>/revert`
- `POST /api/experiments/<experiment_id>/tanakh-run`

SSE emits small invalidation payloads only. It does not push full graph or basin payloads.

TUI behavior:

- `Observatory` ensures the local server is running and opens the current experiment index page
- when an experiment-scoped `observatory_index.html` shell already exists, the TUI may open it immediately and continue refreshing payloads in the background instead of blocking browser launch on export completion
- session-scoped launches may append `?session_id=<session_id>` so the live API and session endpoints bind to the current session rather than the stale session baked into an older export shell
- repeated use is safe and does not create ghost server state
- observatory-originated edits are logged back into the runtime trace surfaces
- static exports must be HTTP-served, either by the EDEN observatory server or another static file server; direct `file://` opening is not a supported runtime path for the v1 bundle
- runtime status exposes frontend build freshness so stale checked-in assets can warn at runtime and fail CI/release checks

## Validation

Validated in this patch:

- CLI port fallback from an occupied requested port to a nearby free port
- live API preview / commit / revert plus graph / basin / transcript read endpoints against a real experiment
- SSE invalidation stream emits compact refresh messages after observatory commits
- the checked-in React observatory bundle builds and emits `build-meta.json`
- Tanakh surface export writes canonical/derived sidecars plus a manual-review render-validation harness
